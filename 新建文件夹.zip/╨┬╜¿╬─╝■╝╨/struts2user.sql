
  CREATE SEQUENCE  user_seq
  MINVALUE 1 
  MAXVALUE 9999999
  INCREMENT BY 1 
  START WITH 1
  NOCACHE 
  NOORDER
  NOCYCLE ;
 



create table struts2user(

id number(5) primary key,
username varchar2(15),
password varchar2(15),
sex varchar2(5)


);

insert into struts2user values(user_seq.nextval,'������','admin','��');
insert into struts2user values(user_seq.nextval,'ϵͳ����Ա','admin','��');
insert into struts2user values(user_seq.nextval,'����','admin','��');
insert into struts2user values(user_seq.nextval,'����','admin','��');
insert into struts2user values(user_seq.nextval,'brownkivi','admin','��');
commit;

