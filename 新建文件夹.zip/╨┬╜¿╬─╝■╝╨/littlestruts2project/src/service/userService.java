package service;

import java.util.List;

import dao.userdao;
import entity.user;

public class userService {
	
	private userdao dao;
	
	
	public void insertservice(String username,String sex,String password)
	{
		dao=new userdao();
		dao.insert(username, sex, password);
	}

	public void deleteSerivce(String username)
	{
		dao=new userdao();
		dao.delete(username);
	}
	
	public void modifyService(String username,String password)
	{
		dao=new userdao();
	     dao.modify(username, password);
	}
	
	public List<user> queryService(String username)
	{
		
		dao=new userdao();
		return dao.query(username);
		
	}
	
	public List<user> checkService()
	{
		dao=new userdao();
		return dao.check();
		
	}
	
	public boolean loginService(String username,String password)
	{
		dao=new userdao();
		return dao.login(username, password);
		
	}
}
