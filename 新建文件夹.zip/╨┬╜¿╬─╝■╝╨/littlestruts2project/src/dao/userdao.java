package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import entity.user;
import util.connector;

public class userdao {

	 private List<user> list=new ArrayList<>();

	public  void insert(String username,String sex,String password)
	{
		
		Connection conn=null;
		Statement st=null;
		conn=connector.getconn();
		
		try {
			st=conn.createStatement();
			String sql="insert into struts2user values(user_seq.nextval,'"+username+"','"+password+"','"+sex+"')";
			
			st.executeUpdate(sql);
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	public  void delete(String username)
	{
		Connection conn=null;
		Statement st=null;
		conn=connector.getconn();
		
		try {
			st=conn.createStatement();
			String sql="delete from struts2user where username='"+username+"'";
			st.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void modify(String username,String password)
	{

		Connection conn=null;
		Statement st=null;
		conn=connector.getconn();
		
		try {
			st=conn.createStatement();
			String sql="update struts2user set password='"+password+"' where username='"+username+"'";
			st.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//ע��ʱ����ѯ�û����Ƿ��ظ�
	
	public  List<user>  query(String username)
	{
		
		user u=null;
		Connection conn=null;
		Statement st=null;
		ResultSet rs=null;
		conn=connector.getconn();
		
		try {
			st=conn.createStatement();
			String sql="select * from struts2user where username='"+username+"'";
			rs=st.executeQuery(sql);
			while(rs.next())
			{
				u=new user();
				u.setUsername(rs.getString("username"));
				u.setPassword(rs.getString("password"));
				u.setSex(rs.getString("sex"));
				list.add(u);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	
	//��ʾ�����û�
	
	public List<user> check()
	{
		user u=null;
		Connection conn=null;
		Statement st=null;
		ResultSet rs=null;
		conn=connector.getconn();
		
		try {
			st=conn.createStatement();
			String sql="select * from struts2user";
			rs=st.executeQuery(sql);
			while(rs.next())
			{
				u=new user();
				u.setUsername(rs.getString("username"));
				u.setPassword(rs.getString("password"));
				u.setSex(rs.getString("sex"));
				list.add(u);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	
	public boolean login(String username,String password)
	{
		boolean b=false;
		Connection conn=null;
		Statement st=null;
	
		conn=connector.getconn();
		
		try {
			st=conn.createStatement();
			String sql="select * from struts2user where username='"+username+"' and password='"+password+"'";
			int a=st.executeUpdate(sql);
			if(a>0)
			{
				b=true;
				return b;
			}
		
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return b;
	}
	
	
	
	
}
