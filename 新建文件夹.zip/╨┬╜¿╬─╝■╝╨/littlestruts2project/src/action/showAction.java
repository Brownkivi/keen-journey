package action;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

import entity.user;
import service.userService;

public class showAction extends ActionSupport {
	

	private userService service;

	
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		service=new userService();
		Map session=ActionContext.getContext().getSession();
		List<user> list=new ArrayList<>();
		list=service.checkService();
		session.put("list", list);
		if(list.size()>0)
		{
			session.put("check", true);
			return SUCCESS;
		}
			
		else
		{
			this.addActionError("�������û�����");
			session.put("check", false);
			return "error";
		}
	}
	
	
	

}
