package action;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

import service.userService;

public class queryAction extends ActionSupport {
	
	private entity.user user;
	private userService service;
	public entity.user getUser() {
		return user;
	}
	public void setUser(entity.user user) {
		this.user = user;
	}
	public userService getService() {
		return service;
	}
	public void setService(userService service) {
		this.service = service;
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		service=new userService();
		List<entity.user> list=new ArrayList<>();
		list=service.queryService(user.getUsername());
		Map session=ActionContext.getContext().getSession();
		session.remove("querylist");
		if(list.size()>0)
			
		{
			session.put("querylist", list);
			return SUCCESS;
		}

		else
		{
			this.addActionError("�û���������");
			return "error";
					
		}
		
	}
	

}
