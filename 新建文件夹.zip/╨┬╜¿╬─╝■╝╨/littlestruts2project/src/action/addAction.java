package action;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

import service.userService;

public class addAction extends ActionSupport {
	
	private entity.user user;
	private userService service;
	private List<entity.user> list=new ArrayList<>();
	public entity.user getUser() {
		return user;
	}
	public void setUser(entity.user user) {
		this.user = user;
	}
	public userService getService() {
		return service;
	}
	public void setService(userService service) {
		this.service = service;
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		
		service=new userService();
		
		Map session=ActionContext.getContext().getSession();
		
		list=service.queryService(user.getUsername());
		session.remove("registeruser");
		if(!list.contains(user))
		{
			service.insertservice(user.getUsername(), user.getSex(), user.getPassword());
			session.put("registeruser",user);
			return SUCCESS;
	   
		}
		
		else
		{
			this.addActionError("�û����Ѵ���");
			return "error";
		}
		
	
			
			
	}

	

}
