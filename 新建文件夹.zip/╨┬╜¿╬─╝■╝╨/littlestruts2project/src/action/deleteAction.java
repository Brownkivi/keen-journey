package action;

import java.util.Map;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

import entity.user;
import service.userService;

public class deleteAction extends ActionSupport{
	
	private userService service;

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		
		service=new userService();
		Map session=ActionContext.getContext().getSession();
		String username=(String) session.get("nowuser");
		if(username!=null)
		{
		service.deleteSerivce(username);
		session.remove("nowuser");
		return SUCCESS;
		}
		else
		{
			this.addActionError("��ǰû���û���¼");
			return SUCCESS;
		}
	}
	
	
	
	
	

}
