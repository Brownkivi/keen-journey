package action;

import java.util.Map;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

import service.userService;

public class loginAction extends ActionSupport{
	
	private entity.user user;
	private userService service;
	public entity.user getUser() {
		return user;
	}
	public void setUser(entity.user user) {
		this.user = user;
	}
	public userService getService() {
		return service;
	}
	public void setService(userService service) {
		this.service = service;
	}
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		
		Map session=ActionContext.getContext().getSession();
		service=new userService();
		boolean b=service.loginService(user.getUsername(), user.getPassword());
		
		if(b)
		{
			session.put("nowuser", user.getUsername());
			return SUCCESS;
		}
		
		else
		{
			this.addActionError("�û������������");
			return "error";
		}
		
	}
	

}
