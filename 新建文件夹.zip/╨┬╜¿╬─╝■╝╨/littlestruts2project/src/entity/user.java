package entity;

public class user {

	private String username;
	private String sex;
	private String password;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public user(String username, String sex, String password) {
		super();
		this.username = username;
		this.sex = sex;
		this.password = password;
	}
	public user() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
