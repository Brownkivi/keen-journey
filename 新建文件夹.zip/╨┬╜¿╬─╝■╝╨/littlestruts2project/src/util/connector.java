package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class connector {

	static String driverclass="oracle.jdbc.driver.OracleDriver";
	static String url="jdbc:oracle:thin:@localhost:1521:GKLUQU";
	static String user="student";
	static String password="student";
	
	public static Connection getconn(){
		
		Connection conn=null;
		try {
			Class.forName(driverclass);
			conn=DriverManager.getConnection(url, user, password);
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return conn;
		
	}
	
	
}
